﻿pulse-console · 数据大屏引擎（示例资源包）
包含：组件说明 / 示例配置 JSON / 快速上手文档。
视频演示素材来源：Pexels Video（Pexels License，可免费商用，无需署名），
线上地址：https://videos.pexels.com/video-files/3129957/3129957-sd_960_540_25fps.mp4
