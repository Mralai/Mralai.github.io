﻿nitro-notes · 极简效率笔记（示例资源包）
包含：使用说明 / 快捷键表 / 示例数据文件。
演示素材来源：Picsum 图片（Unsplash License，可免费商用，无需署名）。
